package experiment

const (
	ReconcileFailedReason = "ReconcileFailed"
)
