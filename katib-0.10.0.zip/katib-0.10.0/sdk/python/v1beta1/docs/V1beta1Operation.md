# V1beta1Operation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operation_type** | **str** |  | [optional] 
**parameters** | [**list[V1beta1ParameterSpec]**](V1beta1ParameterSpec.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


