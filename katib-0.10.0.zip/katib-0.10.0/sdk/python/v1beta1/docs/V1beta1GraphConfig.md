# V1beta1GraphConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**input_sizes** | **list[int]** |  | [optional] 
**num_layers** | **int** |  | [optional] 
**output_sizes** | **list[int]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


