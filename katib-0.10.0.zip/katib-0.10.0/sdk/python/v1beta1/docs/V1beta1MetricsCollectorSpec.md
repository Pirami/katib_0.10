# V1beta1MetricsCollectorSpec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**collector** | [**V1beta1CollectorSpec**](V1beta1CollectorSpec.md) |  | [optional] 
**source** | [**V1beta1SourceSpec**](V1beta1SourceSpec.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


