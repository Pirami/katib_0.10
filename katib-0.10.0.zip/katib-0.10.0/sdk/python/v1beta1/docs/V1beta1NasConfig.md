# V1beta1NasConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**graph_config** | [**V1beta1GraphConfig**](V1beta1GraphConfig.md) |  | [optional] 
**operations** | [**list[V1beta1Operation]**](V1beta1Operation.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


