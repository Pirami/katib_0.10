# V1alpha3TemplateSpec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config_map_name** | **str** |  | [optional] 
**config_map_namespace** | **str** |  | [optional] 
**template_path** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


