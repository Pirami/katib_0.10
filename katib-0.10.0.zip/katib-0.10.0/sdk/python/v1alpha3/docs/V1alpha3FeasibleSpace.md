# V1alpha3FeasibleSpace

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**list** | **list[str]** |  | [optional] 
**max** | **str** |  | [optional] 
**min** | **str** |  | [optional] 
**step** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


