# V1alpha3TrialAssignment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the suggestion | [optional] 
**parameter_assignments** | [**list[V1alpha3ParameterAssignment]**](V1alpha3ParameterAssignment.md) | Suggestion results | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


