# V1alpha3CollectorSpec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**custom_collector** | [**V1Container**](V1Container.md) | When kind is \&quot;customCollector\&quot;, this field will be used | [optional] 
**kind** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


