# V1alpha3FilterSpec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metrics_format** | **list[str]** | When the metrics output follows format as this field specified, metricsCollector collects it and reports to metrics server, it can be \&quot;&lt;metric_name&gt;: &lt;float&gt;\&quot; or else | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


