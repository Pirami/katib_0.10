# V1alpha3MetricsCollectorSpec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**collector** | [**V1alpha3CollectorSpec**](V1alpha3CollectorSpec.md) |  | [optional] 
**source** | [**V1alpha3SourceSpec**](V1alpha3SourceSpec.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


