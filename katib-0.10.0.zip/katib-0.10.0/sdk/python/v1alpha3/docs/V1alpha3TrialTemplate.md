# V1alpha3TrialTemplate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**go_template** | [**V1alpha3GoTemplate**](V1alpha3GoTemplate.md) |  | [optional] 
**retain** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


