# V1alpha3EarlyStoppingSpec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**early_stopping_algorithm_name** | **str** |  | [optional] 
**early_stopping_settings** | [**list[V1alpha3EarlyStoppingSetting]**](V1alpha3EarlyStoppingSetting.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


