# V1alpha3Observation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metrics** | [**list[V1alpha3Metric]**](V1alpha3Metric.md) | Key-value pairs for metric names and values | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


