# V1alpha3NasConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**graph_config** | [**V1alpha3GraphConfig**](V1alpha3GraphConfig.md) |  | [optional] 
**operations** | [**list[V1alpha3Operation]**](V1alpha3Operation.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


