# V1alpha3Operation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operation_type** | **str** |  | [optional] 
**parameters** | [**list[V1alpha3ParameterSpec]**](V1alpha3ParameterSpec.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


