# V1alpha3GoTemplate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**raw_template** | **str** |  | [optional] 
**template_spec** | [**V1alpha3TemplateSpec**](V1alpha3TemplateSpec.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


